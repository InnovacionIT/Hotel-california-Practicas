package com.example.hotelcaliforniaModelo;

public abstract class ClaseBase {
    int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
